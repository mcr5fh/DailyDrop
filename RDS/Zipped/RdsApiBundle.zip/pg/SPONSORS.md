node-postgres is made possible by the helpful contributors from the community well as the following generous supporters on [Patreon](https://www.patreon.com/node_postgres).

# Leaders
- [MadKudu](https://www.madkudu.com) - [@madkudu](https://twitter.com/madkudu)

# Supporters
- John Fawcett
- Lalit Kapoor [@lalitkapoor](https://twitter.com/lalitkapoor)
- Paul Frazee [@pfrazee](https://twitter.com/pfrazee)
- Rein Petersen
- Arnaud Benhamdine [@abenhamdine](https://twitter.com/abenhamdine)
- Matthew Welke
